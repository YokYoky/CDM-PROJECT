﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports MySql.Data.MySqlClient
Public Class hrsys
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Initialize the ComboBoxPosition control and add positions
        ComboBoxPosition.Items.AddRange({"CEO", "Director", "Manager", "Team Lead", "Regular", "Security", "Maintenance"})
    End Sub
    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            ' Uncheck other checkboxes
            CheckBox2.Checked = False
            CheckBox3.Checked = False

            ' Update combobox items
            ComboBoxPosition.Items.Clear()
            ComboBoxPosition.Items.Add("CEO")
        End If
    End Sub

    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked Then
            ' Uncheck other checkboxes
            CheckBox1.Checked = False
            CheckBox3.Checked = False

            ' Update combobox items
            ComboBoxPosition.Items.Clear()
            ComboBoxPosition.Items.AddRange({"Director", "Manager", "Team Lead", "Regular"})
        End If
    End Sub

    Private Sub CheckBox3_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox3.CheckedChanged
        If CheckBox3.Checked Then
            ' Uncheck other checkboxes
            CheckBox1.Checked = False
            CheckBox2.Checked = False

            ' Update combobox items
            ComboBoxPosition.Items.Clear()
            ComboBoxPosition.Items.AddRange({"Security", "Maintenance"})
        End If
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        query = "INSERT INTO employee (fname, lname, ID, position, salary) VALUES (@fname, @lname, @ID, @position, @salary)"
        cmd = New MySqlCommand
        cmd.Connection = conn
        Using command As New MySqlCommand(query, conn)
            ' Set parameter values from textboxes
            command.Parameters.AddWithValue("@fname", TextBoxFirstName.Text)
            command.Parameters.AddWithValue("@lname", TextBoxLastName.Text)
            command.Parameters.AddWithValue("@ID", TextBoxID.Text)
            command.Parameters.AddWithValue("@position", ComboBoxPosition.SelectedItem.ToString())
            command.Parameters.AddWithValue("@salary", TextBoxSalary.Text)

            Try
                conn.Open()
                command.ExecuteNonQuery()
                MessageBox.Show("Employee inserted successfully.")
                ' Clear textboxes after successful insertion
                TextBoxFirstName.Clear()
                TextBoxLastName.Clear()
                TextBoxID.Clear()
                ComboBoxPosition.SelectedIndex = -1
                TextBoxSalary.Clear()
            Catch ex As Exception
                MessageBox.Show("Error: " + ex.Message)
            End Try
            conn.Close()
        End Using
    End Sub

    Private Sub ComboBoxPosition_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBoxPosition.SelectedIndexChanged
        ' Display the salary based on the selected position
        Select Case ComboBoxPosition.SelectedItem.ToString()
            Case "CEO"
                TextBoxSalary.Text = "180000.00"
            Case "Director"
                TextBoxSalary.Text = "120000.00"
            Case "Manager"
                TextBoxSalary.Text = "60000.00"
            Case "Team Lead"
                TextBoxSalary.Text = "40000.00"
            Case "Regular"
                TextBoxSalary.Text = "25000.00"
            Case "Security"
                TextBoxSalary.Text = "15000.00"
            Case "Maintenance"
                TextBoxSalary.Text = "10000.00"
            Case Else
                TextBoxSalary.Text = ""
        End Select
    End Sub
End Class